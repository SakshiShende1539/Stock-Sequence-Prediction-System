import numpy as np
import pandas as pd
import yfinance as yf
import joblib
import os
import warnings
warnings.filterwarnings('ignore')

from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau, ModelCheckpoint

TICKER = 'RELIANCE.NS'
START_DATE = '2018-01-01'
END_DATE = pd.Timestamp.today().strftime('%Y-%m-%d')
SEQUENCE_LEN = 60
FEATURES = ['Open', 'High', 'Low', 'Close', 'Volume']
TARGET_IDX = 3

print(f"Downloading {TICKER} data...")
raw = yf.download(TICKER, start=START_DATE, end=END_DATE, progress=False)

if isinstance(raw.columns, pd.MultiIndex):
    raw.columns = raw.columns.get_level_values(0)

df = raw[FEATURES].dropna().copy()
print(f"Data downloaded: {df.shape}")

scaler = MinMaxScaler(feature_range=(0, 1))
scaled_data = scaler.fit_transform(df[FEATURES].values)

X, y = [], []
for i in range(len(scaled_data) - SEQUENCE_LEN):
    X.append(scaled_data[i : i + SEQUENCE_LEN])
    y.append(scaled_data[i + SEQUENCE_LEN, TARGET_IDX])
X, y = np.array(X), np.array(y)

split = int(len(X) * 0.80)
X_train, y_train = X[:split], y[:split]

model = Sequential([
    LSTM(128, return_sequences=True, input_shape=(SEQUENCE_LEN, len(FEATURES))),
    Dropout(0.2),
    LSTM(64, return_sequences=True),
    Dropout(0.2),
    LSTM(32, return_sequences=False),
    Dropout(0.2),
    Dense(16, activation='relu'),
    Dense(1)
])

model.compile(optimizer=Adam(learning_rate=0.001), loss='mean_squared_error', metrics=['mae'])

os.makedirs('model', exist_ok=True)

print("Training model...")
# Using 5 epochs instead of 100 for quicker setup
model.fit(X_train, y_train, epochs=5, batch_size=32, validation_split=0.10, verbose=1)

model.save('model/lstm_model.h5')
joblib.dump(scaler, 'model/scaler.pkl')
print("Model and Scaler saved successfully in model/")
