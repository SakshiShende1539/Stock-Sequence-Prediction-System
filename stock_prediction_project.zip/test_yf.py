import yfinance as yf
print(f"yfinance version: {yf.__version__}")
from datetime import datetime, timedelta
end = datetime.today()
start = end - timedelta(days=90)
data = yf.download("RELIANCE.NS", start=start.strftime("%Y-%m-%d"), end=end.strftime("%Y-%m-%d"))
print(f"Rows: {len(data)}")
print(data.head())
